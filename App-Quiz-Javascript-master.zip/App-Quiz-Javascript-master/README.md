# App Quiz Javascript

Esse código é do [tutorial feito no meu canal do YouTube](https://www.youtube.com/watch?v=IV34pOplBsY)
